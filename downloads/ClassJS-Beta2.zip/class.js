(function (global, ClassJS)
{
    // ClassJS Should be Defined globally inorder to work
    if (typeof Define === "function" && Define.amd) Define(ClassJS);
    else if (typeof module === "object") module.exports = ClassJS();
    else global.ClassJS = ClassJS();
}

(this, function ()
{
    "use strict";

    var Factory = function() {};
    var slice = Array.prototype.slice;

    // The ClassJS function. This function creates the
    // core of the ClassJS library. This is where the
    // magic happens. Every property in the 'body' function
    // is copied into the prototype of the created object
    var ClassJS = function(superclass, body)
    {
        // The base prototype
        var base = Factory.prototype = typeof superclass === "function" ? superclass.prototype : superclass;
        
        // Clone the factory prototype
        var prototype = new Factory;
        
        // Clone all the properties
        var properties = body.apply(prototype, slice.call(arguments, 2).concat(base));
        
        if (typeof properties === "object")
            for (var key in properties)
                prototype[key] = properties[key];
                
        // Clone the non overridden properties from the base class
        for (var key in base)
            if (!prototype.hasOwnProperty(key))
                prototype[key] = base[key];
                
        // If there is no constructor, return the prototype
        if (!prototype.hasOwnProperty("create"))
            return prototype;
            
        // If a constructor is present, change the prototype
        var create = prototype.create;
        create.prototype = prototype;
        return create;
    };

    // Defines a class from a prototype. Only
    // use this to Define a class that doesn't
    // inherit from any other class. (Obviously
    // this means the class Extends from Object)
    ClassJS.Define = function (prototype)
    {
        // If there is no constructor, create an empty constructor
        if (!prototype.hasOwnProperty("create"))
            prototype.create = function(){}
            
        // Utility functions for all the objects
        prototype.instanceOf = function(cname)
        {
            return (this instanceof cname);
        };
    
        // Create the class with the constructor and prototype
        var create = prototype.create;
        create.prototype = prototype;
        return create;
    };

    // Defines a class from a 'body' which Extends a
    // superclass. Use this function if you want to
    // inherit a super class and use the Methods Defined.
    ClassJS.Extend = function(superclass, body)
    {
        return ClassJS(superclass, function (base)
        {
            // base accessor
            this.base = base;
            
            // Utility instanceOf function
            this.instanceOf = function(cname)
            {
                return (this instanceof cname || this.base.instanceOf(cname));
            };
            
            return body;
        });
    };
    
    // Simple Overload function that allows a function
    // to be overloaded. This function is not meant to
    // be called directly, since it's syntax doesn't give
    // you the feel of writing java-like classes.
    ClassJS.Overload = function(original, matches, fn)
    {
        return function()
        {
            // If there are no matches, or if the first match
            // type is specified as 'None', just overload without
            // any checking of arguments.
            if (matches.length == 0 || matches[0] == 'None')
            {
                return fn.apply(this, arguments);
            }
            
            // Check the number of arguments. The number of arguments
            // should match the number of types specified in matches.
            if (matches.length == arguments.length)
            {
                // Start looping over the arguments passed and check the types
                for (var i = 0, type; i < matches.length; i++)
                {
                    // The types are required to be specified as strings.
                    // We assume that they are strings and are not null
                    // or of undefined type
                    if (typeof arguments[i] != "undefined" && arguments[i] != null)
                    {
                        // Get the type using the regex from the name of the constructor
                        type = (/function (.{1,})\(/).exec(arguments[i].constructor.toString())[1];
                        
                        // Break if the type didn't match the type of the passed argument.
                        // Don't Break if the passed one was '*' an asterisk that allows
                        // to pass in any type.
                        if (matches[i] != "*" && ("||"+matches[i].replace(/ /g, "")+"||").split("||"+type+"||").length <= 1)
                            break;
                    }
                    else break;
                }
                
                // If 'i' is equal to the number of matches, go
                // on and apply the function to this function.
                if (i == matches.length)
                    return fn.apply(this, arguments);
            }
            
            // If the overload is specified incorrectly
            // fall-back to the default original function.
            return original.apply(this, arguments);
        }
    }
    
    // ClassJS function to wrap up functions as class
    // methods. Use this if you want to support overloading
    // of functions. A method is a list of functions along
    // with arrays that specify type information of function
    // arguments all with a single name. This transforms your
    // functions such that it will return a single function
    // that calls the correct sub-function by checking the
    // number of arguments and their types.
    ClassJS.Method = function()
    {
        // Create a new empty function for this method.
        var fn = new Function;
        
        // The arguments passed should be a multiple of two,
        // since we also need type informations. If you don't
        // want type checking, just use an empty array.
        if (arguments.length % 2 != 0)
            console.error("Arguments of ClassJS.Method need to be a multiple of two. Please include the types of arguments as an array");
            
        // Overload every function in the list
        for (var i=0; i<arguments.length; i+=2)
        {
            var arr = arguments[i];
            var func = arguments[i+1];
            
            fn = ClassJS.Overload(fn, arr, func);
        }
        
        return fn;
    }

    // Return the ClassJS object to register globally
    return ClassJS;
}));