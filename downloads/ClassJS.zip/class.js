(function (global, ClassJS)
{
    // ClassJS Should be defined globally inorder to work
    if (typeof define === "function" && define.amd) define(ClassJS);
    else if (typeof module === "object") module.exports = ClassJS();
    else global.ClassJS = ClassJS();
}

(this, function ()
{
    "use strict";

    var Factory = function() {};
    var slice = Array.prototype.slice;

    // The ClassJS function. This function creates the
    // core of the ClassJS library. This is where the
    // magic happens. Every property in the 'body' function
    // is copied into the prototype of the created object
    var ClassJS = function(superclass, body)
    {
        // The base prototype
        var base = Factory.prototype = typeof superclass === "function" ? superclass.prototype : superclass;
        
        // Clone the factory prototype
        var prototype = new Factory;
        
        // Clone all the properties
        var properties = body.apply(prototype, slice.call(arguments, 2).concat(base));
        
        if (typeof properties === "object")
            for (var key in properties)
                prototype[key] = properties[key];
                
        // Clone the non overridden properties from the base class
        for (var key in base)
            if (!prototype.hasOwnProperty(key))
                prototype[key] = base[key];
                
        // If there is no constructor, return the prototype
        if (!prototype.hasOwnProperty("create"))
            return prototype;
            
        // If a constructor is present, change the prototype
        var create = prototype.create;
        create.prototype = prototype;
        return create;
    };

    // Defines a class from a prototype. Only
    // use this to define a class that doesn't
    // inherit from any other class. (Obviously
    // this means the class extends from Object)
    ClassJS.define = function (prototype) {
        // If there is no constructor, create an empty constructor
        if (!prototype.hasOwnProperty("create"))
            prototype.create = function(){}
            
        // Utility functions for all the objects
        prototype.instanceOf = function(cname)
        {
            return (this instanceof cname);
        };
    
        // Create the class with the constructor and prototype
        var create = prototype.create;
        create.prototype = prototype;
        return create;
    };

    // Defines a class from a 'body' which extends a
    // superclass. Use this function if you want to
    // inherit a super class and use the methods defined.
    ClassJS.extend = function (superclass, body) {
        return ClassJS(superclass, function (base) {
            // base accessor
            this.base = base;
            
            // Utility instanceOf function
            this.instanceOf = function(cname)
            {
                return (this instanceof cname || this.base.instanceOf(cname));
            };
            
            return body;
        });
    };

    // Return the ClassJS object to register globally
    return ClassJS;
}));